<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(

	'g_filled (highlight set)' => $set . '_e900',
	'g_outline (highlight set)' => $set . '_e901',
	'quote01_filled (highlight set)' => $set . '_e902',
	'quote_outline (highlight set)' => $set . '_e903',
	'quote02_filled (highlight set)' => $set . '_e904'
);

