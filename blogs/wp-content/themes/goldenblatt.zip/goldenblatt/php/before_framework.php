<?php

require_once( get_template_directory() . '/php/before_framework/customize_params.php' );
require_once( get_template_directory() . '/php/before_framework/functions.php' );