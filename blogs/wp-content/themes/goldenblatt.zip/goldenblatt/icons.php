<?php
$icons = sanitize_text_field('

@font-face{ font-family:"Business";src:url("' . get_parent_theme_file_uri( 'fonts/Business/Business.woff' ) . '") format("woff"),url("' . get_parent_theme_file_uri( 'fonts/Business/Business.ttf' ) . '") format("truetype"); }
*[data-ico-business]:before{ font-family:Business;content:attr(data-ico-business); }

@font-face{ font-family:"Design";src:url("' . get_parent_theme_file_uri( 'fonts/Design/Design.woff' ) . '") format("woff"),url("' . get_parent_theme_file_uri( 'fonts/Design/Design.ttf' ) . '") format("truetype"); }
*[data-ico-design]:before{ font-family:Design;content:attr(data-ico-design); }

@font-face{ font-family:"Dripicons";src:url("' . get_parent_theme_file_uri( 'fonts/Dripicons/Dripicons.woff' ) . '") format("woff"),url("' . get_parent_theme_file_uri( 'fonts/Dripicons/Dripicons.ttf' ) . '") format("truetype"); }
*[data-ico-dripicons]:before{ font-family:Dripicons;content:attr(data-ico-dripicons); }

@font-face{ font-family:"Essential";src:url("' . get_parent_theme_file_uri( 'fonts/Essential/Essential.woff' ) . '") format("woff"),url("' . get_parent_theme_file_uri( 'fonts/Essential/Essential.ttf' ) . '") format("truetype"); }
*[data-ico-essential]:before{ font-family:Essential;content:attr(data-ico-essential); }

@font-face{ font-family:"FontAwesome";src:url("' . get_parent_theme_file_uri( 'fonts/FontAwesome/FontAwesome.woff' ) . '") format("woff"),url("' . get_parent_theme_file_uri( 'fonts/FontAwesome/FontAwesome.ttf' ) . '") format("truetype"); }
*[data-ico-fontawesome]:before{ font-family:FontAwesome;content:attr(data-ico-fontawesome); }

@font-face{ font-family:"FontAwesome5Brands";src:url("' . get_parent_theme_file_uri( 'fonts/FontAwesome5Brands/FontAwesome5Brands.woff' ) . '") format("woff"),url("' . get_parent_theme_file_uri( 'fonts/FontAwesome5Brands/FontAwesome5Brands.ttf' ) . '") format("truetype"); }
*[data-ico-fontawesome5brands]:before{ font-family:FontAwesome5Brands;content:attr(data-ico-fontawesome5brands); }

@font-face{ font-family:"FontAwesome5Regular";src:url("' . get_parent_theme_file_uri( 'fonts/FontAwesome5Regular/FontAwesome5Regular.woff' ) . '") format("woff"),url("' . get_parent_theme_file_uri( 'fonts/FontAwesome5Regular/FontAwesome5Regular.ttf' ) . '") format("truetype"); }
*[data-ico-fontawesome5regular]:before{ font-family:FontAwesome5Regular;content:attr(data-ico-fontawesome5regular); }

@font-face{ font-family:"FontAwesome5Solid";src:url("' . get_parent_theme_file_uri( 'fonts/FontAwesome5Solid/FontAwesome5Solid.woff' ) . '") format("woff"),url("' . get_parent_theme_file_uri( 'fonts/FontAwesome5Solid/FontAwesome5Solid.ttf' ) . '") format("truetype"); }
*[data-ico-fontawesome5solid]:before{ font-family:FontAwesome5Solid;content:attr(data-ico-fontawesome5solid); }

@font-face{ font-family:"Highlight";src:url("' . get_parent_theme_file_uri( 'fonts/Highlight/Highlight.woff' ) . '") format("woff"),url("' . get_parent_theme_file_uri( 'fonts/Highlight/Highlight.ttf' ) . '") format("truetype"); }
*[data-ico-highlight]:before{ font-family:Highlight;content:attr(data-ico-highlight); }

@font-face{ font-family:"Icon7Stroke";src:url("' . get_parent_theme_file_uri( 'fonts/Icon7Stroke/Icon7Stroke.woff' ) . '") format("woff"),url("' . get_parent_theme_file_uri( 'fonts/Icon7Stroke/Icon7Stroke.ttf' ) . '") format("truetype"); }
*[data-ico-icon7stroke]:before{ font-family:Icon7Stroke;content:attr(data-ico-icon7stroke); }

@font-face{ font-family:"Law";src:url("' . get_parent_theme_file_uri( 'fonts/Law/Law.woff' ) . '") format("woff"),url("' . get_parent_theme_file_uri( 'fonts/Law/Law.ttf' ) . '") format("truetype"); }
*[data-ico-law]:before{ font-family:Law;content:attr(data-ico-law); }', array() );